# Mellow Club ♡

A cute Discord-inspired social community web app starter: public rooms, customizable emoji avatars, realtime text chat, room invites, a shared number-guessing game, and optional LiveKit voice rooms.

## Deploy the website + realtime chat

**Important:** Vercel hosts the React/Vite website. The Socket.IO chat server must run separately (for example, on Render); Vercel's static frontend deployment does not run this long-lived Socket.IO server. Deploy both parts for chat to work.

### 1. Upload this project to GitHub

1. Create a new repository on https://github.com/.
2. Upload the project files and folders (not the ZIP file itself). Keep `package.json`, `src/`, `server/`, and `vercel.json` at the repository root.
3. Do not upload `.env` or any secret keys.

### 2. Deploy the chat server to Render

1. Open https://render.com/ and create a **New Web Service** connected to this GitHub repository.
2. Set **Build Command** to `npm install && npm run build:server`.
3. Set **Start Command** to `node dist-server/index.js`.
4. Add an environment variable named `CLIENT_ORIGIN` with the exact production Vercel website origin, for example `https://mellow-club-yourname.vercel.app` (no trailing slash). You can add multiple origins separated by commas.
5. Deploy and open `https://YOUR-SERVER.onrender.com/health`. It should return JSON with `"ok":true`.

### 3. Deploy the frontend to Vercel

1. Open https://vercel.com/ and import the same GitHub repository.
2. Framework preset: **Vite**. Build command: `npm run build`. Output directory: `dist`. The included `vercel.json` also sets these defaults.
3. In Vercel Project Settings → Environment Variables, add:
   - Name: `VITE_SERVER_URL`
   - Value: `https://YOUR-SERVER.onrender.com` (replace with your real Render service URL; no trailing slash)
   - Apply to **Production** (and Preview too if you want preview deployments to connect).
4. Deploy or redeploy the Vercel project so the environment variable is included in the build.
5. Copy your production Vercel URL and make sure Render's `CLIENT_ORIGIN` matches it exactly. If you change it, redeploy the Render service.

### 4. Optional voice rooms

1. Create a project at https://cloud.livekit.io/.
2. Set `LIVEKIT_URL`, `LIVEKIT_API_KEY`, and `LIVEKIT_API_SECRET` as environment variables on **Render only**.
3. Never put `LIVEKIT_API_SECRET` in a `VITE_` variable or expose it in frontend code.
4. Use the site over HTTPS and allow microphone access in the browser.

## Run locally

Requirements: Node.js 20+ and npm.

```bash
npm install
npm run dev
```

Open `http://localhost:5173`. In development, the app connects to the local chat server at `http://localhost:3001` by default. For a production frontend build, set `VITE_SERVER_URL` to the deployed backend URL.

## Included in this starter

- Realtime Socket.IO room presence and text messages
- Public room creation and invite-link copying
- Emoji avatar and color customization (saved in this browser)
- Shared room number-guessing mini-game
- Optional LiveKit voice integration via server-issued token

## Demo limitations

This is a starter, not a fully moderated production platform. Rooms, messages, and presence are kept in server memory; restarting the server clears them. There is no account/password system, persistent database, private messaging, friend-request workflow, or report/block enforcement yet. Invite links point to public rooms, not access-controlled private rooms. Do not use this as a secure private space.

A single backend instance is a reasonable starting point for a small pilot, but actual capacity depends on activity and hosting limits. LiveKit handles audio separately. Before opening to strangers, add a database, authentication, moderation/report/block tools, abuse prevention, age-appropriate safety rules, and monitoring.
