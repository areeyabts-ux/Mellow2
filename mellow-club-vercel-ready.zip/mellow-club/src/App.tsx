import { useEffect, useMemo, useRef, useState } from "react";
import { io, Socket } from "socket.io-client";
import { LiveKitRoom, RoomAudioRenderer, useLocalParticipant, useParticipants } from "@livekit/components-react";
import "@livekit/components-styles";
import {
  Bell, ChevronDown, Compass, Gamepad2, Hash, Headphones, Heart, LogOut, MessageCircle,
  Mic, MicOff, Plus, Search, Send, Settings, ShieldCheck, Smile, Sparkles, Users, Volume2, X
} from "lucide-react";

const SERVER = import.meta.env.VITE_SERVER_URL || (import.meta.env.DEV ? "http://localhost:3001" : "");
const avatars = ["🐻","🐰","🐸","🐱","🐼","🦊","🐣","🐹","🐨","🦄","🐙","🧸"];
const colors = ["#F8DCE8","#DDE8FF","#DDF5E6","#FFF0CE","#E8DFFF","#D9F4F5"];
type Room = { id:string; name:string; description:string; category:string; count:number };
type Person = { id:string; name:string; avatar:string; color:string };
type Msg = { id:string; roomId:string; userId:string; name:string; avatar:string; text:string; time:number };
type VoiceToken = { token:string; url:string };

function App() {
  const socketRef = useRef<Socket | null>(null);
  const [connected, setConnected] = useState(false);
  const [name, setName] = useState(localStorage.getItem("mellow-name") || "");
  const [avatar, setAvatar] = useState(localStorage.getItem("mellow-avatar") || "🐻");
  const [color, setColor] = useState(localStorage.getItem("mellow-color") || "#F8DCE8");
  const [profileReady, setProfileReady] = useState(false);
  const [rooms, setRooms] = useState<Room[]>([]);
  const [currentRoom, setCurrentRoom] = useState<Room | null>(null);
  const [people, setPeople] = useState<Person[]>([]);
  const [messages, setMessages] = useState<Msg[]>([]);
  const [text, setText] = useState("");
  const [tab, setTab] = useState<"chat"|"people"|"games">("chat");
  const [showCreate, setShowCreate] = useState(false);
  const [roomName, setRoomName] = useState("");
  const [roomDescription, setRoomDescription] = useState("");
  const [notice, setNotice] = useState("");
  const [voiceToken, setVoiceToken] = useState<VoiceToken | null>(null);
  const [voiceLoading, setVoiceLoading] = useState(false);
  const [voiceError, setVoiceError] = useState("");
  const [search, setSearch] = useState("");
  const [roundMessage, setRoundMessage] = useState("");
  const [guess, setGuess] = useState("");
  const [mobilePanel, setMobilePanel] = useState(false);
  const chatEnd = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!SERVER) {
      setNotice("เว็บเปิดแล้ว แต่ยังไม่ได้ตั้งค่า VITE_SERVER_URL ให้ชี้ไปยังเซิร์ฟเวอร์แชต (Render) นะ ♡");
      return;
    }
    const socket = io(SERVER, { transports: ["websocket", "polling"] });
    socketRef.current = socket;
    socket.on("connect", () => setConnected(true));
    socket.on("disconnect", () => { setConnected(false); setVoiceToken(null); });
    socket.on("rooms:update", (data: Room[]) => setRooms(data));
    socket.on("room:joined", (data: {room:Room; users:Person[]; messages:Msg[]}) => {
      setCurrentRoom(data.room); setPeople(data.users); setMessages(data.messages || []);
      setVoiceToken(null); setVoiceError(""); setTab("chat");
    });
    socket.on("presence:update", (data: Person[]) => setPeople(data));
    socket.on("chat:new", (msg: Msg) => setMessages(prev => [...prev.filter(m => m.id !== msg.id), msg].slice(-150)));
    socket.on("minigame:guess:started", (data: {startedBy:string; hint:string}) => setRoundMessage(`🎲 ${data.startedBy} เริ่มเกมทายเลข! ${data.hint}`));
    socket.on("minigame:guess:attempt", (data: {name:string; guess:string}) => setRoundMessage(`${data.name} ทาย ${data.guess}... ยังไม่ใช่!`));
    socket.on("minigame:guess:won", (data: {name:string; guess:string}) => setRoundMessage(`🎉 ${data.name} ทายถูกแล้ว! เลขคือ ${data.guess}`));
    return () => { socket.disconnect(); };
  }, []);

  useEffect(() => { chatEnd.current?.scrollIntoView({ behavior: "smooth" }); }, [messages]);

  const enter = () => {
    const cleanName = name.trim().slice(0,20);
    if (!cleanName) { setNotice("ใส่ชื่อเล่นก่อนน้า ♡"); return; }
    localStorage.setItem("mellow-name", cleanName);
    localStorage.setItem("mellow-avatar", avatar);
    localStorage.setItem("mellow-color", color);
    setName(cleanName); setProfileReady(true);
    socketRef.current?.emit("profile:join", { name: cleanName, avatar, color, roomId: "lobby" });
  };

  const joinRoom = (roomId: string) => {
    if (!profileReady) { setNotice("สร้างตัวละครก่อนแล้วค่อยเข้าห้องน้า"); return; }
    socketRef.current?.emit("room:join", roomId, (res: any) => { if (!res?.ok) setNotice(res?.error || "เข้าห้องไม่ได้"); });
  };

  const send = (e?: React.FormEvent) => {
    e?.preventDefault();
    const value = text.trim();
    if (!value) return;
    if (value.startsWith("!guess ")) {
      socketRef.current?.emit("minigame:guess", { guess: value.slice(7).trim() }, (res:any) => { if (res?.error) setNotice(res.error); });
      setText(""); return;
    }
    socketRef.current?.emit("chat:send", { text: value }, (res:any) => { if (res?.error) setNotice(res.error); });
    setText("");
  };

  const createRoom = (e: React.FormEvent) => {
    e.preventDefault();
    socketRef.current?.emit("room:create", { name: roomName, description: roomDescription, category: "ชิลล์" }, (res:any) => {
      if (!res?.ok) { setNotice(res?.error || "สร้างห้องไม่สำเร็จ"); return; }
      setShowCreate(false); setRoomName(""); setRoomDescription("");
      joinRoom(res.room.id);
    });
  };

  const startVoice = async () => {
    if (!SERVER) { setVoiceError("ยังไม่ได้ตั้งค่าเซิร์ฟเวอร์แชตใน VITE_SERVER_URL"); return; }
    if (!profileReady || !currentRoom) { setNotice("เข้าห้องก่อนเริ่มคุยเสียงนะ"); return; }
    setVoiceLoading(true); setVoiceError("");
    try {
      const identity = `u${(socketRef.current?.id || crypto.randomUUID()).replace(/[^a-zA-Z0-9_-]/g,"").slice(0,24)}`;
      const roomNameSafe = currentRoom.id.replace(/[^a-zA-Z0-9_-]/g, "-").slice(0,64);
      const res = await fetch(`${SERVER}/api/voice-token`, { method:"POST", headers:{"Content-Type":"application/json"}, body:JSON.stringify({ identity, roomName:roomNameSafe }) });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "ขอ token เสียงไม่สำเร็จ");
      setVoiceToken(data);
    } catch (err) { setVoiceError(err instanceof Error ? err.message : "เชื่อมต่อเสียงไม่ได้"); }
    finally { setVoiceLoading(false); }
  };

  const visiblePeople = useMemo(() => people.filter(p => p.name.toLowerCase().includes(search.toLowerCase())), [people, search]);
  const copyInvite = async () => {
    const url = `${location.origin}/?room=${encodeURIComponent(currentRoom?.id || "lobby")}`;
    try { await navigator.clipboard.writeText(url); setNotice("คัดลอกลิงก์ห้องแล้ว ♡"); }
    catch { setNotice(url); }
  };

  useEffect(() => {
    const invite = new URLSearchParams(location.search).get("room");
    if (invite && profileReady) joinRoom(invite);
  }, [profileReady]);

  if (!profileReady) return <div className="onboarding">
    <div className="onboard-card">
      <div className="brand-mark big">m<span>♡</span></div>
      <div className="eyebrow"><Sparkles size={14}/> YOUR LITTLE CORNER OF THE INTERNET</div>
      <h1>Welcome to<br/><em>Mellow Club</em></h1>
      <p className="muted">มาเป็นตัวเอง แล้วค่อย ๆ รู้จักเพื่อนใหม่กัน ♡</p>
      <label className="field-label">ชื่อเล่นของคุณ</label>
      <input className="text-field" value={name} maxLength={20} onChange={e=>setName(e.target.value)} placeholder="เช่น little bean"/>
      <label className="field-label">เลือกตัวละคร</label>
      <div className="avatar-grid">{avatars.map(a=><button key={a} className={`avatar-choice ${avatar===a?"selected":""}`} onClick={()=>setAvatar(a)}>{a}</button>)}</div>
      <label className="field-label">สีประจำตัว</label>
      <div className="color-row">{colors.map(c=><button aria-label={`สี ${c}`} key={c} onClick={()=>setColor(c)} className={`color-choice ${color===c?"selected":""}`} style={{background:c}}/>)}</div>
      <button className="primary-btn full" onClick={enter}>เข้าชมรมเลย <Heart size={16} fill="currentColor"/></button>
      <p className="tiny muted center">เดโมนี้ใช้ชื่อเล่น ไม่ต้องสมัครบัญชี · อย่าแชร์ข้อมูลส่วนตัว</p>
      {notice && <p className="error-text">{notice}</p>}
    </div>
  </div>;

  return <div className="app-shell">
    <aside className={`server-rail ${mobilePanel?"show":""}`}>
      <div className="rail-logo">m<span>♡</span></div>
      <button className="rail-button active" title="หน้าแรก"><Heart/></button>
      <button className="rail-button" title="ค้นหาชุมชน" onClick={()=>setTab("people")}><Compass/></button>
      <div className="rail-separator"/>
      <button className="rail-server active-server">🌷</button>
      <button className="rail-server">🎧</button>
      <button className="rail-server">🎨</button>
      <button className="rail-add" onClick={()=>setShowCreate(true)} title="สร้างห้อง"><Plus/></button>
    </aside>

    <aside className={`channel-sidebar ${mobilePanel?"show":""}`}>
      <div className="community-head"><div><div className="community-name">mellow club <ChevronDown size={15}/></div><div className="community-sub">พื้นที่เล็ก ๆ ของพวกเรา</div></div><button className="icon-btn" onClick={()=>setShowCreate(true)} title="สร้างห้อง"><Plus size={18}/></button></div>
      <div className="sidebar-section"><div className="section-title">YOUR ROOMS <button onClick={()=>setShowCreate(true)}><Plus size={14}/></button></div>
        {rooms.filter(r=>r.name.toLowerCase().includes(search.toLowerCase()) || r.description.toLowerCase().includes(search.toLowerCase())).map(r=><button key={r.id} className={`channel ${currentRoom?.id===r.id?"selected":""}`} onClick={()=>joinRoom(r.id)}><Hash size={16}/><span>{r.name}</span><span className="room-count">{r.count||""}</span></button>)}
      </div>
      <div className="sidebar-section">
        <div className="section-title">DISCOVER</div>
        <button className={`channel ${tab==="people"?"selected":""}`} onClick={()=>setTab("people")}><Users size={16}/> หาเพื่อนใหม่</button>
        <button className={`channel ${tab==="games"?"selected":""}`} onClick={()=>setTab("games")}><Gamepad2 size={16}/> มินิเกม</button>
      </div>
      <div className="sidebar-bottom"><div className="profile-mini"><div className="mini-avatar" style={{background:color}}>{avatar}</div><div className="profile-text"><b>{name}</b><small><span className={`status-dot ${connected?"online":""}`}/>{connected?"ออนไลน์":(!SERVER?"ยังไม่ตั้งค่าเซิร์ฟเวอร์":"กำลังเชื่อมต่อ...")}</small></div><button className="icon-btn" onClick={()=>{setProfileReady(false);setVoiceToken(null);}} title="แก้ไขตัวละคร"><Settings size={17}/></button></div></div>
    </aside>

    <main className="main-panel">
      <header className="topbar">
        <button className="mobile-menu icon-btn" onClick={()=>setMobilePanel(!mobilePanel)}><Users size={18}/></button>
        <div className="topbar-room"><span className="hash-large">#</span><div><b>{currentRoom?.name || "Mellow Club"}</b><small>{currentRoom?.description || "พื้นที่เล็ก ๆ ที่คุณเป็นตัวเองได้"}</small></div></div>
        <div className="top-actions"><div className="search-wrap"><Search size={15}/><input value={search} onChange={e=>setSearch(e.target.value)} placeholder="ค้นหาห้องหรือเพื่อน"/></div><button className="icon-btn" title="การแจ้งเตือน"><Bell size={18}/></button><button className="invite-btn" onClick={copyInvite}>เชิญเพื่อน +</button></div>
      </header>

      <div className="workspace">
        <section className="chat-area">
          {tab==="chat" && <>
            <div className="welcome-banner"><div className="welcome-flower">✿</div><div><div className="eyebrow">A LITTLE HELLO GOES A LONG WAY</div><h2>ยินดีต้อนรับสู่ {currentRoom?.name || "Mellow Club"} ♡</h2><p>เริ่มบทสนทนาเล็ก ๆ แล้วอาจได้เพื่อนคนโปรดคนใหม่ก็ได้นะ</p></div><div className="banner-deco">☁️ ✨</div></div>
            <div className="messages-list">
              {messages.length===0 && <div className="empty-chat"><div className="empty-icon">💌</div><b>เป็นคนแรกที่ทักทายไหม?</b><span>ส่งข้อความแรกของห้องได้เลย</span></div>}
              {messages.map(m=><div className="message" key={m.id}><div className="message-avatar" style={{background:people.find(p=>p.id===m.userId)?.color || "#F0E5FF"}}>{m.avatar}</div><div className="message-body"><div className="message-meta"><b>{m.name}</b><time>{new Date(m.time).toLocaleTimeString([], {hour:"2-digit",minute:"2-digit"})}</time></div><p>{m.text}</p></div></div>)}
              <div ref={chatEnd}/>
            </div>
            <form className="composer" onSubmit={send}><button type="button" className="composer-emoji" onClick={()=>setText(t=>t+"♡")}><Smile size={20}/></button><input value={text} onChange={e=>setText(e.target.value)} placeholder={`ส่งข้อความถึง #${currentRoom?.name || "ห้องแชต"}...`} maxLength={500}/><button className="send-btn" type="submit" aria-label="ส่งข้อความ"><Send size={18}/></button></form>
          </>}
          {tab==="people" && <div className="tab-page"><div className="eyebrow">MEET YOUR PEOPLE</div><h2>คนในห้องนี้ ♡</h2><p className="muted">เริ่มจากทักทายกันเบา ๆ ก็ได้นะ</p><div className="people-grid">{visiblePeople.map(p=><div className="person-card" key={p.id}><div className="person-avatar" style={{background:p.color}}>{p.avatar}</div><b>{p.name}{p.id===socketRef.current?.id?" (คุณ)":""}</b><span className="online-label">● อยู่ในห้อง</span><button className="secondary-btn" onClick={()=>setNotice(`ลองทัก ${p.name} ในแชตสาธารณะดูนะ ♡`)}><MessageCircle size={14}/> ทักทาย</button></div>)}</div></div>}
          {tab==="games" && <div className="tab-page"><div className="eyebrow">PLAY A LITTLE</div><h2>มินิเกมในห้อง 🎲</h2><p className="muted">เล่นด้วยกันผ่านแชตได้เลย ไม่ต้องออกจากห้อง</p><div className="game-card"><div className="game-emoji">🔢</div><div className="game-content"><h3>ทายเลข 1–10</h3><p>ให้คนหนึ่งเริ่มเกม แล้วทุกคนลองทายเลขผ่านแชต ใครทายถูกก่อนชนะ!</p><button className="primary-btn" onClick={()=>socketRef.current?.emit("minigame:guess:start",(r:any)=>{if(!r?.ok)setNotice("เข้าห้องก่อนเริ่มเกมนะ");})}>เริ่มรอบใหม่ <Sparkles size={15}/></button></div></div><div className="guess-box"><b>ส่งคำตอบ</b><p>พิมพ์เลข 1–10 แล้วกดทาย หรือพิมพ์ในแชตเป็น <code>!guess 7</code></p><form onSubmit={e=>{e.preventDefault();socketRef.current?.emit("minigame:guess",{guess},(r:any)=>{if(r?.error)setNotice(r.error);});setGuess("");}}><input value={guess} onChange={e=>setGuess(e.target.value)} placeholder="เลข 1–10" maxLength={2}/><button className="secondary-btn">ทายเลย</button></form>{roundMessage&&<div className="round-message">{roundMessage}</div>}</div></div>}
        </section>

        <aside className="member-sidebar">
          <div className="members-head"><span>สมาชิกในห้อง</span><span className="member-count">{people.length}</span></div>
          <div className="member-list">{people.map(p=><div className="member-row" key={p.id}><div className="member-avatar" style={{background:p.color}}>{p.avatar}<i/></div><div className="member-name">{p.name}{p.id===socketRef.current?.id?" (คุณ)":""}</div></div>)}</div>
          <div className="voice-card"><div className="voice-card-head"><div className="voice-icon"><Volume2 size={17}/></div><div><b>ห้องเสียง</b><small>{voiceToken?"กำลังเชื่อมต่อ":"คุยกันสด ๆ ได้เลย"}</small></div></div>
            {voiceToken ? <LiveKitRoom token={voiceToken.token} serverUrl={voiceToken.url} connect audio video={false} onDisconnected={()=>setVoiceToken(null)} onError={e=>setVoiceError(e.message)}><VoiceControls onLeave={()=>setVoiceToken(null)}/><RoomAudioRenderer/></LiveKitRoom> : <button className="voice-join" onClick={startVoice} disabled={voiceLoading}>{voiceLoading?"กำลังเชื่อมต่อ...":<><Headphones size={16}/> เข้าห้องเสียง</>}</button>}
            {voiceError && <div className="voice-error">{voiceError}</div>}
          </div>
          <div className="safety-note"><ShieldCheck size={15}/><span>เป็นมิตร เคารพกัน และอย่าแชร์ข้อมูลส่วนตัว</span></div>
        </aside>
      </div>
      {notice && <div className="toast" role="status">{notice}<button onClick={()=>setNotice("")}><X size={14}/></button></div>}
    </main>

    {showCreate && <div className="modal-backdrop" onClick={()=>setShowCreate(false)}><form className="modal" onSubmit={createRoom} onClick={e=>e.stopPropagation()}><button type="button" className="modal-close icon-btn" onClick={()=>setShowCreate(false)}><X/></button><div className="modal-icon">🌷</div><h2>สร้างห้องใหม่</h2><p className="muted">สร้างมุมเล็ก ๆ ให้คนที่ชอบอะไรเหมือนกัน</p><label className="field-label">ชื่อห้อง</label><input className="text-field" required minLength={2} maxLength={32} value={roomName} onChange={e=>setRoomName(e.target.value)} placeholder="เช่น คนชอบแมว"/><label className="field-label">คำอธิบาย</label><input className="text-field" maxLength={100} value={roomDescription} onChange={e=>setRoomDescription(e.target.value)} placeholder="ห้องนี้ไว้คุยเรื่องอะไรน้า"/><button className="primary-btn full">สร้างห้อง ♡</button></form></div>}
  </div>;
}

function VoiceControls({onLeave}:{onLeave:()=>void}) {
  const { isMicrophoneEnabled, localParticipant } = useLocalParticipant();
  const participants = useParticipants();
  return <div className="voice-controls"><span className="voice-live"><i/> {participants.length} คน</span><button className="voice-control-btn" onClick={()=>localParticipant.setMicrophoneEnabled(!isMicrophoneEnabled)} title={isMicrophoneEnabled?"ปิดไมค์":"เปิดไมค์"}>{isMicrophoneEnabled?<Mic size={16}/>:<MicOff size={16}/>}</button><button className="voice-control-btn leave" onClick={onLeave} title="ออกจากห้องเสียง"><LogOut size={16}/></button></div>;
}
export default App;
