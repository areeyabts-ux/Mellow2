import express from "express";
import cors from "cors";
import { createServer } from "node:http";
import { Server, Socket } from "socket.io";
import { AccessToken } from "livekit-server-sdk";
import { randomUUID } from "node:crypto";

const PORT = Number(process.env.PORT || 3001);
const CLIENT_ORIGIN = (process.env.CLIENT_ORIGIN || "http://localhost:5173").split(",").map(s => s.trim());
const app = express();
app.use(cors({ origin: CLIENT_ORIGIN, credentials: true }));
app.use(express.json({ limit: "20kb" }));

app.get("/health", (_req, res) => res.json({ ok: true, service: "mellow-club" }));

app.post("/api/voice-token", async (req, res) => {
  const { identity, roomName } = req.body ?? {};
  if (!process.env.LIVEKIT_URL || !process.env.LIVEKIT_API_KEY || !process.env.LIVEKIT_API_SECRET) {
    return res.status(503).json({ error: "Voice is not configured yet. Add LiveKit credentials to the server environment." });
  }
  if (typeof identity !== "string" || typeof roomName !== "string" ||
      !/^[a-zA-Z0-9_-]{1,32}$/.test(identity) || !/^[a-zA-Z0-9_-]{1,64}$/.test(roomName)) {
    return res.status(400).json({ error: "Invalid identity or room name." });
  }
  try {
    const token = new AccessToken(process.env.LIVEKIT_API_KEY, process.env.LIVEKIT_API_SECRET, {
      identity,
      ttl: "1h",
      metadata: JSON.stringify({ app: "mellow-club" })
    });
    token.addGrant({ roomJoin: true, room: roomName, canPublish: true, canSubscribe: true });
    res.json({ token: await token.toJwt(), url: process.env.LIVEKIT_URL });
  } catch {
    res.status(500).json({ error: "Could not create voice token." });
  }
});

const httpServer = createServer(app);
const io = new Server(httpServer, {
  cors: { origin: CLIENT_ORIGIN, methods: ["GET", "POST"] },
  maxHttpBufferSize: 1e6
});

type RoomInfo = { id: string; name: string; description: string; category: string; members: Set<string>; createdAt: number };
type UserInfo = { id: string; name: string; avatar: string; color: string; roomId: string; joinedAt: number };
type ChatMessage = { id: string; roomId: string; userId: string; name: string; avatar: string; text: string; time: number };
const rooms = new Map<string, RoomInfo>();
const users = new Map<string, UserInfo>();
const messages = new Map<string, ChatMessage[]>();
const RATE_LIMIT = new Map<string, number[]>();

const seedRooms = [
  { id: "lobby", name: "The Lobby", description: "มาทักทายและหาเพื่อนใหม่ ♡", category: "ชิลล์" },
  { id: "late-night", name: "Late Night Club", description: "คุยเรื่องชีวิตตอนดึก ๆ", category: "ชิลล์" },
  { id: "creative-corner", name: "Creative Corner", description: "วาดรูป งานคราฟต์ และไอเดีย", category: "สร้างสรรค์" },
  { id: "game-room", name: "Mini Game Room", description: "มาเล่นเกมสั้น ๆ ด้วยกัน", category: "เกม" }
];
for (const r of seedRooms) {
  rooms.set(r.id, { ...r, members: new Set(), createdAt: Date.now() });
  messages.set(r.id, []);
}
const clean = (v: unknown, max: number) => typeof v === "string" ? v.trim().replace(/[<>]/g, "").slice(0, max) : "";
const publicRoom = (r: RoomInfo) => ({ id: r.id, name: r.name, description: r.description, category: r.category, count: r.members.size });
const roomUsers = (roomId: string) => [...rooms.get(roomId)!.members].map(id => users.get(id)).filter(Boolean).map(u => ({
  id: u!.id, name: u!.name, avatar: u!.avatar, color: u!.color
}));
const emitRooms = () => io.emit("rooms:update", [...rooms.values()].map(publicRoom));
const emitPresence = (roomId: string) => io.to(roomId).emit("presence:update", roomUsers(roomId));
function allowMessage(socketId: string) {
  const now = Date.now();
  const recent = (RATE_LIMIT.get(socketId) || []).filter(t => now - t < 10_000);
  if (recent.length >= 8) { RATE_LIMIT.set(socketId, recent); return false; }
  recent.push(now); RATE_LIMIT.set(socketId, recent); return true;
}

io.on("connection", (socket: Socket) => {
  socket.emit("rooms:update", [...rooms.values()].map(publicRoom));

  socket.on("profile:join", (payload: { name?: string; avatar?: string; color?: string; roomId?: string }, ack?: (v: unknown) => void) => {
    const name = clean(payload?.name, 20) || "little bean";
    const avatar = clean(payload?.avatar, 8) || "🐻";
    const color = /^#[0-9a-fA-F]{6}$/.test(payload?.color || "") ? payload.color! : "#E8D9FF";
    const requested = clean(payload?.roomId, 64) || "lobby";
    const roomId = rooms.has(requested) ? requested : "lobby";
    const old = users.get(socket.id);
    if (old) {
      rooms.get(old.roomId)?.members.delete(socket.id);
      socket.leave(old.roomId);
      emitPresence(old.roomId);
    }
    const user: UserInfo = { id: socket.id, name, avatar, color, roomId, joinedAt: Date.now() };
    users.set(socket.id, user);
    rooms.get(roomId)!.members.add(socket.id);
    socket.join(roomId);
    socket.emit("room:joined", { room: publicRoom(rooms.get(roomId)!), users: roomUsers(roomId), messages: (messages.get(roomId) || []).slice(-80) });
    emitPresence(roomId); emitRooms();
    ack?.({ ok: true, user: { id: socket.id, name, avatar, color } });
  });

  socket.on("room:join", (rawRoomId: unknown, ack?: (v: unknown) => void) => {
    const user = users.get(socket.id);
    const roomId = clean(rawRoomId, 64);
    if (!user || !rooms.has(roomId)) return ack?.({ ok: false, error: "Room not found or profile not set." });
    if (user.roomId === roomId) return ack?.({ ok: true });
    const oldRoom = user.roomId;
    rooms.get(oldRoom)?.members.delete(socket.id); socket.leave(oldRoom); emitPresence(oldRoom);
    user.roomId = roomId; rooms.get(roomId)!.members.add(socket.id); socket.join(roomId);
    socket.emit("room:joined", { room: publicRoom(rooms.get(roomId)!), users: roomUsers(roomId), messages: (messages.get(roomId) || []).slice(-80) });
    emitPresence(roomId); emitRooms(); ack?.({ ok: true });
  });

  socket.on("room:create", (payload: { name?: string; description?: string; category?: string }, ack?: (v: unknown) => void) => {
    if (!users.has(socket.id)) return ack?.({ ok: false, error: "Join with a profile first." });
    const name = clean(payload?.name, 32);
    if (name.length < 2) return ack?.({ ok: false, error: "Room name must be at least 2 characters." });
    if (rooms.size >= 40) return ack?.({ ok: false, error: "Demo server room limit reached." });
    const id = `${name.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "").slice(0, 30) || "room"}-${randomUUID().slice(0, 6)}`;
    const room: RoomInfo = { id, name, description: clean(payload?.description, 100) || "A new little corner of the internet ♡", category: clean(payload?.category, 20) || "ชิลล์", members: new Set(), createdAt: Date.now() };
    rooms.set(id, room); messages.set(id, []); emitRooms(); ack?.({ ok: true, room: publicRoom(room) });
  });

  socket.on("chat:send", (raw: unknown, ack?: (v: unknown) => void) => {
    const user = users.get(socket.id);
    if (!user) return ack?.({ ok: false, error: "Set up your profile first." });
    if (!allowMessage(socket.id)) return ack?.({ ok: false, error: "ส่งเร็วเกินไป รอสักครู่นะ" });
    const text = clean((raw as { text?: unknown })?.text, 500);
    if (!text) return ack?.({ ok: false, error: "Message is empty." });
    const msg: ChatMessage = { id: randomUUID(), roomId: user.roomId, userId: socket.id, name: user.name, avatar: user.avatar, text, time: Date.now() };
    const list = messages.get(user.roomId) || []; list.push(msg);
    messages.set(user.roomId, list.slice(-150));
    io.to(user.roomId).emit("chat:new", msg); ack?.({ ok: true });
  });

  socket.on("minigame:guess:start", (ack?: (v: unknown) => void) => {
    const user = users.get(socket.id);
    if (!user) return ack?.({ ok: false });
    const answer = String(Math.floor(Math.random() * 10) + 1);
    io.to(user.roomId).emit("minigame:guess:started", { startedBy: user.name, hint: "เลขอยู่ระหว่าง 1–10! พิมพ์ !guess ตามด้วยเลข เช่น !guess 7", roundId: randomUUID() });
    // Keep the answer on the server; store it privately per room.
    activeRounds.set(user.roomId, { answer, startedAt: Date.now() });
    ack?.({ ok: true });
  });

  socket.on("disconnect", () => {
    const user = users.get(socket.id);
    if (user) { rooms.get(user.roomId)?.members.delete(socket.id); users.delete(socket.id); emitPresence(user.roomId); emitRooms(); }
    RATE_LIMIT.delete(socket.id);
  });
});

const activeRounds = new Map<string, { answer: string; startedAt: number }>();
// Handle guesses as normal chat commands; server checks the answer without exposing it.
io.on("connection", (socket: Socket) => {
  socket.on("minigame:guess", (raw: unknown, ack?: (v: unknown) => void) => {
    const user = users.get(socket.id);
    const round = user ? activeRounds.get(user.roomId) : undefined;
    const guess = clean((raw as { guess?: unknown })?.guess, 2);
    if (!user || !round) return ack?.({ ok: false, error: "ยังไม่มีเกมที่กำลังเล่นอยู่" });
    if (!/^(10|[1-9])$/.test(guess)) return ack?.({ ok: false, error: "ทายเลข 1–10 นะ" });
    if (guess === round.answer) {
      io.to(user.roomId).emit("minigame:guess:won", { name: user.name, guess });
      activeRounds.delete(user.roomId);
      ack?.({ ok: true, won: true });
    } else {
      io.to(user.roomId).emit("minigame:guess:attempt", { name: user.name, guess });
      ack?.({ ok: true, won: false });
    }
  });
});

httpServer.listen(PORT, () => console.log(`Mellow Club server listening on :${PORT}`));
